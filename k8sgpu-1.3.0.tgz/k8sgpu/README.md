# Deploying the k8s.gpu agent in Kubernetes

k8s.gpu is a Virtual Kubelet Provider to easily access remote GPU Clouds from any Kubernetes cluster.

It's a convenient and ideal solution for scalable GPU-powered applications by connecting GPUs additional computational capacity provided by 3dy party GPU Cloud Providers.

## Requirements

* [Helm 3](https://github.com/helm/helm/releases) is required when installing the K8sGPU Agent in Kubernetes.
  Follow Helm’s official [steps](https://helm.sh/docs/intro/install/) for installing helm on your particular operating system.

* Any Kubernetes cluster 1.24+

* A `kubeconfig` file accessing the remote cluster of the GPUs Provider.

## Quick Start

1. Install the Chart:

```
helm repo add clastix https://clastix.github.io/charts
helm repo update

helm upgrade --install k8sgpu-agent clastix/k8sgpu-agent \
    --namespace kube-system \
    --set "k8sgpuOptions.tenantName=your_tenant_name" \
    --set-file "kubeConfigSecret.content=/path/to/your/gpu-remote-cluster/kubeconfig"
```

2. Upgrade the Chart

```
helm upgrade k8sgpu-agent clastix/k8sgpu-agent \
    --namespace kube-system \
    --set "k8sgpuOptions.tenantName=your_tenant_name" \
    --set-file "kubeConfigSecret.content=/path/to/your/gpu-remote-cluster/kubeconfig"
```

3. Uninstall the Chart
  
```
helm uninstall k8sgpu-agent --namespace kube-system
```

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` | Define the affinity for the k8s.gpu agent Deployment for particular setups. |
| autoscaling.enabled | bool | `false` |  |
| autoscaling.maxReplicas | int | `100` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| extraArgs | list | `[]` | A list of extra arguments to add to the controller default ones. |
| fullnameOverride | string | `""` |  |
| healthProbeBindAddress | int | `8081` | The address the probe endpoint binds to. (default 8081) |
| image.pullPolicy | string | `"IfNotPresent"` | Container image pull policy. |
| image.repository | string | `"clastix/k8sgpu-agent"` | Container image repository. |
| image.tag | string | `""` | Overrides the image tag whose default is the chart appVersion. |
| imagePullSecrets | list | `[]` | Define the image pull secret, default container image is publicly downloadable. |
| k8sgpuOptions.csrSigner | string | `"kubelet"` | The Virtual Kubelet certificate signer, supported values: kubelet (for kubeadm based clusters), aws. (default: kubelet) |
| k8sgpuOptions.tenantName | string | `""` | Your provider Tenant name: must be configured according to your subscription. |
| k8sgpuOptions.tenantNamespace | string | `"gpu"` | The logic namespace of your remote workloads. (default gpu) |
| kubeConfigSecret.content | string | `""` |  |
| kubeConfigSecret.create | bool | `true` | Specifies whether the secret to access remote GPUs cluster should be created |
| kubeConfigSecret.name | string | `""` | The name of the secret to access remote GPUs cluster. If not set and create is true, a name is generated using the fullname template |
| livenessProbe | object | `{"httpGet":{"path":"/healthz","port":"healthcheck"},"initialDelaySeconds":15,"periodSeconds":20}` | The livenessProbe for the controller container. |
| loggingDevel.enabled | bool | `false` | (string) Development Mode defaults(encoder=consoleEncoder,logLevel=Debug,stackTraceLevel=Warn). Production Mode defaults(encoder=jsonEncoder,logLevel=Info,stackTraceLevel=Error) (default false) |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` | Define a Node Selector to force scheduling and execution on a subset of nodes. |
| podAnnotations | object | `{}` | The additional pod annotations for the k8s.gpu agent Pods. |
| podSecurityContext | object | `{}` | The Pod security context for the k8s.gpu agent Deployment. |
| readinessProbe | object | `{"httpGet":{"path":"/readyz","port":"healthcheck"},"initialDelaySeconds":5,"periodSeconds":10}` | The readinessProbe for the controller container. |
| replicaCount | int | `1` | The replicas of the k8s.gpu agent, leader election is always involved. |
| resources | object | `{}` | Assign specific resources for the k8s.gpu agent Deployment. |
| securityContext | object | `{}` | The security context for the k8s.gpu agent Deployment. |
| service.create | bool | `false` |  |
| service.port | int | `80` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| tolerations | list | `[]` | Define a set of Tolerations to satisfy taints of specific nodes. |

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Dario Tranchitella | <dario@clastix.io> |  |
| Adriano Pezzuto | <adriano@clastix.io> |  |

